module.exports = {
  purge: ['./src/**/*.vue'],
  theme: {
    container: {
      center: true,
    },
    extend: {},
  },
  variants: {
    cursor: ['focus'],
  },
  plugins: [],
}
